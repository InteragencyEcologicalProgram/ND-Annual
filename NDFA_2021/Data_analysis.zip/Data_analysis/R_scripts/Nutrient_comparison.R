#NDFS 2021 Nutrient Data Check
#Laura Twardochleb
#Updated 4/5/22

rm(list = ls())

#packages
lapply(c("tidyverse", "lubridate", "viridis", "ggpubr"), require, character.only = TRUE)

#set directory
setwd("~/NDFA/2021/R_scripts")

#################### Examine Bryte nutrient data #######################################################################################
mydir = "~/NDFA/2021/Data/Discrete"
wq <- list.files(path = mydir, pattern = "*.csv", full.names = T) %>% map_df(~read_csv(., col_types = cols(.default = "c"))) 

#data cleaning: remove rows with NA in collection date, remove rows with "duplicate or matrix spike" in notes
#subset to Dissolved ortho-phosphate, Dissolved Ammonia, Dissolved Nitrate + Nitrite
wq2<-wq%>%filter(Analyte%in%c("Dissolved Ammonia", "Dissolved Nitrate + Nitrite", "Dissolved ortho-Phosphate"))%>%
  filter(!is.na(CollectionDate))%>%filter(is.na(Notes))

#assign stations to upstream and downstream
downstream<-c("RYI - Cache Slough","Liberty at S End",  "RVB - Rio Vista", "BL5 -Below Toe Drain", "PRS")
upstream<-c("Toe Drain at Rd. 22", "RMB - Rominger", "Ridge Cut Slough","Toe Drain at STTD", "Toe Drain YB LISBON", "Toe Drain@ I-80")

wq2$Region<-ifelse(wq2$ShortStationName %in% downstream, "Downstream",
                   ifelse(wq2$ShortStationName %in% upstream, "Upstream", "Middle Sac River"))
wq2$Region<-factor(wq2$Region, levels=c("Upstream", "Downstream", "Middle Sac River"))

#for non-detects, assign NA: any value with a < symbol
wq2$Result<-ifelse(wq2$Result %in% c("<0.05", "<0.01"), NA, wq2$Result)

#assign flow pulse period: before, during, after, need to change code, this was written for 2020 data
wq2$Collectiondate2<-as.Date(wq2$CollectionDate, format="%m/%d/%y")
wq2$PulsePeriod<-ifelse(wq2$Collectiondate2 < "2020-09-11", "Before", 
                        ifelse(wq2$Collectiondate2 > "2020-09-14", "After", "During"))
wq2$PulsePeriod<-factor(wq2$PulsePeriod, levels=c("Before", "During", "After"))

#calculate mean for each analyte by region and pulse period; assume NAs (non-detects, equal zero)
wq2$Result2<-ifelse(is.na(wq2$Result),0, wq2$Result)
nutrient_means<-wq2%>%group_by(Analyte, Region, PulsePeriod)%>%summarize(mean=mean(as.numeric(Result2), na.rm=TRUE), sd=sd(as.numeric(Result2), na.rm=TRUE))

#change factor levels for Analytes for plotting
nutrient_means$Analyte[nutrient_means$Analyte=="Dissolved Ammonia"]<-"Ammonia"
nutrient_means$Analyte[nutrient_means$Analyte=="Dissolved ortho-Phosphate"]<-"Phosphate"
nutrient_means$Analyte[nutrient_means$Analyte=="Dissolved Nitrate + Nitrite"]<-"Nitrate/Nitrite"

#plot mean and sd by analyte, pulse period, region, filter Middle Sac River
nutrients_plot<-nutrient_means%>%filter(Region!="Middle Sac River")%>%ggplot(aes(x=Region, y=mean, fill=Region))+geom_bar(stat="identity")+geom_errorbar(aes(ymin=0, ymax=mean+sd))+facet_wrap(Analyte*PulsePeriod~.)+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab("Bryet data mean concentration (mg/L)")+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/Nutrients_comparison/Bryte_nutrients.png", nutrients_plot, height=6, width=7, dpi=600)

############## plot number of non-detects in Bryte nutrient data for ammonia, phosphate, nitrate/nitrite
n_detects_plot<-wq2%>%filter(Region!="Middle Sac River")%>%filter(is.na(Result))%>%group_by(Analyte, Region, PulsePeriod)%>%count((Result))%>%
  ggplot(aes(x=Region, y=n, fill=Region))+geom_bar(stat="identity")+facet_wrap(Analyte*PulsePeriod~.)+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab("Number of non-detects in 2021 Bryte samples")+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/Nutrients_comparison/Bryte_nutrients_non_detects.png", n_detects_plot, height=6, width=7, dpi=600)


#################### Examine SFSU nutrient data #######################################################################################
sfsu<-read_csv("~/NDFA/2021/Data/Collaborator Data/SFSU_nutrients_2021.csv")

#assign station to upstream and downstream
downstream2<-c("BL5", "PRS", "LIB", "RYI", "RVB")
upstream2<-c("RMB", "RD22", "I80TD", "LIS", "STTD", "DWT", "WWT")

sfsu$Region<-ifelse(sfsu$Station %in% downstream2, "Downstream",
                   ifelse(sfsu$Station %in% upstream2, "Upstream", "Middle Sac River"))
sfsu$Region<-factor(sfsu$Region, levels=c("Upstream", "Downstream", "Middle Sac River"))

#lengthen data frame, all results in one column
sfsu_long<-pivot_longer(sfsu, cols=c(nitrate_nitrite, nitrite, orthophosphate, ammonia), names_to="Analyte", values_to="Result")

#for non-detects, assign NA: 0 values
sfsu_long$Result2<-ifelse(sfsu_long$Result == 0, NA, sfsu_long$Result)

#assign pulse period
sfsu_long$Date2<-as.Date(sfsu_long$Date, format="%m/%d/%y")
sfsu_long$PulsePeriod<-ifelse(sfsu_long$Date2 < "2020-09-11", "Before", 
                        ifelse(sfsu_long$Date2 > "2020-09-14", "After", "During"))
sfsu_long$PulsePeriod<-factor(sfsu_long$PulsePeriod, levels=c("Before", "During", "After"))

#calculate mean for each analyte by region and pulse period; assume NAs (non-detects, equal zero)

#change factor levels for Analytes for plotting

#plot mean and sd by analyte, pulse period, region, filter Middle Sac River



############## plot number of non-detects in SFSU nutrient data for ammonia, phosphate, nitrate/nitrite
n_detects_sfsu<-sfsu_long%>%filter(Region!="Middle Sac River")%>%filter(is.na(Result2))%>%group_by(Analyte, Region, PulsePeriod)%>%count((Result2))%>%
  ggplot(aes(x=Region, y=n, fill=Region))+geom_bar(stat="identity")+facet_wrap(Analyte*PulsePeriod~.)+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab("Number of non-detects in 2021 SFSU samples")+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/Nutrients_comparison/sfsu_nutrients_non_detects.png", n_detects_sfsu, height=6, width=7, dpi=600)

