#Summer-Fall Habitat Action Report
#Data analysis of zooplankton, phytoplankton, and water quality from 2020 monitoring
#Laura Twardochleb
#Updated 10/22/21

rm(list = ls())

#packages
lapply(c("CDECRetrieve","tidyverse", "lubridate", "viridis"), require, character.only = TRUE)

#set directory
setwd("~/NDFA/2021/SFHA Report")

#"during" flow pulse period is Sept. 1-16

#####################zooplankton CPUE##################################################################################
zoop_lab<-read_csv("zoop_lab.csv")
zoop_field<-read_csv("zoop_field.csv")

#merge lab and field data files by WDL_SAM_code, date, station
#subset to NDFA only, 150 net, remove extraneous columns
#remove entries where zoop classification is NA
zoop<-left_join(zoop_field, zoop_lab, by=c("Date"="Date", "Station.Code"="Station.Code"))%>%
  select(c("Program", "Date", "Station.Code","ZoopNetType", "Flow_Meter_Start_150", "Flow_Meter_End_150", "Flow_Meter_Speed", "Volume.Mesozooplankton.150", "Subsample.Volume.Mesozooplankton.150", "Volume.Microzooplankton.150", "Subsample.Volume.Microzooplankton.150","OrganismID","ZOOP.COUNT", "ZOOP.CLASSIFICATION","ZOOP.ORGANISM","ZOOP.LIFE"))%>%
  filter(Program=="NDFA")%>%filter(ZoopNetType=="150")%>%filter(!is.na(ZOOP.CLASSIFICATION))%>%filter(Date!="8/5/2014")

#lots of NA entries for organism under classification Harpacticoid, rename to "Harpacticoid spp."
zoop$ZOOP.ORGANISM<-if_else(is.na(zoop$ZOOP.ORGANISM)&zoop$ZOOP.CLASSIFICATION=="Harpacticoids", "Harpacticoid spp.", zoop$ZOOP.ORGANISM)

#calculate zooplankton CPUE; two steps: calculate zooplankton count, then calculate CPUE from count and flow data
#zooplankton count= subsample count/[(subsample volume(mL)*number of subsamples/total sample volume (mL)])
#CPUE= zooplankton count/[(3.14*diameter squared/4)*(endmeter-startmeter*57560/999999)]
zoop$CPUE <- #if Meso
  ifelse(
    (zoop$ZOOP.CLASSIFICATION != "Microzooplankton_Nauplii"), 
    (zoop$ZOOP.COUNT/((zoop$Subsample.Volume.Mesozooplankton.150)/(zoop$Volume.Mesozooplankton.150))/
            (((3.14*0.25)/4)*(((zoop$Flow_Meter_End_150-zoop$Flow_Meter_Start_150)*57560)/999999))
    ),
    ifelse(
      (zoop$ZOOP.CLASSIFICATION == "Microzooplankton_Nauplii"), 
      zoop$ZOOP.COUNT/((zoop$Subsample.Volume.Microzooplankton.150)/(zoop$Volume.Microzooplankton.150))/
        (((3.14*0.25)/4)*(((zoop$Flow_Meter_End_150-zoop$Flow_Meter_Start_150)*57560)/999999))
      ))

#summarize CPUE by classification, date, and site, upstream and downstream

downstream<-c("RVB","RYI",  "LIB", "BL5")
upstream<-c("I80", "RD22", "RMB","RCS", "LIS", "STTD")
#assign regions
zoop$Region<-ifelse(zoop$Station.Code %in% downstream, "Downstream",
                            ifelse(zoop$Station.Code %in% upstream, "Upstream", "Middle Sac River"))
zoop$Region<-factor(zoop$Region, levels=c("Upstream", "Downstream", "Middle Sac River"))
#assign transects
zoop$Transect<-ifelse(zoop$Date %in% c("7/13/2020", "7/14/2020"), "Transect1",
                    ifelse(zoop$Date %in% c("7/27/2020", "7/28/2020"), "Transect2", "Transect3"))

#calculate mean cpue and sum of cpue by region, station, and taxonomic group
zoop2<-zoop%>%group_by(Date, Station.Code, ZOOP.CLASSIFICATION)%>%mutate(mean_cpue=mean(CPUE))%>%mutate(total_cpue=sum(CPUE))
 
#summarize mean total cpue by region and zooplankton taxonomic group
regional_cpue<-zoop2%>%group_by(Region, ZOOP.CLASSIFICATION)%>%summarize(regional_total_cpue=mean(total_cpue), sd_total_cpue=sd(total_cpue))

#summarize cpue by region only: first calculate sum of cpue by site and then take regional mean of cpue across sites
cpue_region_only<-zoop2%>%group_by(Region, Station.Code)%>%summarize(regional_total_cpue=sum(total_cpue))%>%group_by(Region)%>%
  summarize(mean_regional_total_cpue=mean(regional_total_cpue), sd_regional_total_cpue=sd(regional_total_cpue))

#plot CPUE by taxonomic group, region
zoop_plot<-regional_cpue%>%filter(Region!="Middle Sac River")%>%ggplot(aes(x=Region, y=log(regional_total_cpue), fill=Region))+geom_bar(stat="identity")+geom_errorbar(aes(ymin=log(regional_total_cpue)-log(sd_total_cpue), ymax=log(regional_total_cpue)+log(sd_total_cpue)))+facet_wrap(ZOOP.CLASSIFICATION~.)+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab(bquote("Log Mean CPUE (no./"*m^3*')'))+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/SFHA Report/zoop.png", zoop_plot, height=6, width=9, dpi=600)

#plot CPUE by taxonomic group, date, region
zoop_plot2<-cpue_region_only%>%filter(Region!="Middle Sac River")%>%ggplot(aes(x=Region, y=log(mean_regional_total_cpue), fill=Region))+geom_bar(stat="identity")+geom_errorbar(aes(ymin=log(mean_regional_total_cpue)-log(sd_regional_total_cpue), ymax=log(mean_regional_total_cpue)+log(sd_regional_total_cpue)))+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab(bquote("Log Zooplankton CPUE (no./"*m^3*')'))+
  annotate("text", x=0.5, y=25, label="b)", size=8)+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))

#t-test for upstream/downstream differences in total zooplankton
zoop_cpue<-zoop2%>%filter(Region!="Middle Sac River")%>%group_by(Region, Station.Code)%>%summarize(regional_total_cpue=mean(total_cpue))

zoop.t.test<-t.test(log(regional_total_cpue)~Region, zoop_cpue, alternative="two.sided", var.equal=FALSE)
zoop.t.test #no significant difference between regions

#t-tests for upstream/downstream differences in zooplankton groups
zoop3<-zoop2%>%filter(Region!="Middle Sac River")%>%select(Station.Code, Region, ZOOP.CLASSIFICATION, total_cpue)%>%distinct()%>%group_by(Station.Code, Region, ZOOP.CLASSIFICATION)%>%summarize(total_cpue=mean(total_cpue))

#calanoids
calanoids<-filter(zoop3, ZOOP.CLASSIFICATION=="Calanoids")
calanoid.t.test<-t.test(log(total_cpue)~Region, calanoids, alternative="two.sided", var.equal=FALSE)
calanoid.t.test #downstream higher

cladocerans<-filter(zoop3, ZOOP.CLASSIFICATION=="Cladocera")
cladoceran.t.test<-t.test(log(total_cpue)~Region, cladocerans, alternative="two.sided", var.equal=FALSE)
cladoceran.t.test #upstream higher

cyclopoids<-filter(zoop3, ZOOP.CLASSIFICATION=="Cyclopoids")
cyclopoid.t.test<-t.test(log(total_cpue)~Region, cyclopoids, alternative="two.sided", var.equal=FALSE)
cyclopoid.t.test #not significantly different

harpacticoids<-filter(zoop3, ZOOP.CLASSIFICATION=="Harpacticoids")
harpacticoid.t.test<-t.test(log(total_cpue)~Region, harpacticoids, alternative="two.sided", var.equal=FALSE)
harpacticoid.t.test #not significantly different

microzoop<-filter(zoop3, ZOOP.CLASSIFICATION=="Microzooplankton & Nauplii")
microzoop.t.test<-t.test(log(total_cpue)~Region, microzoop, alternative="two.sided", var.equal=FALSE)
microzoop.t.test #not significantly different

####################phytoplankton biomass##############################################################################
#calculate phytoplankton biovolume

phyto<-read_csv("phyto_2020.csv")

## Average all 10 biovolume measurements for each taxon
phyto <- phyto %>%
  mutate(BioV.Avg=rowMeans(select(., Biovolume1:Biovolume10), na.rm = T), .keep = "unused")

## Remove individual measurements
phyto[,30:66] <- NULL

## Calculate unit abundance per mL (Density)
phyto <- phyto %>%
  mutate(Density = Unit_Abundance * Factor)

## Calculate Cells per mL (only used in Biovolume calcs)
phyto <- phyto %>%
  mutate(Cells.per.mL = Density * Number_of_cells_per_unit)

## Calculate Biovolume per mL 
phyto <- phyto %>%
  mutate(BioV.per.mL = Cells.per.mL * BioV.Avg)

#data cleaning: remove NAs in sample date, assign regions, assign phyto groups
phyto2<-phyto%>%filter(!is.na(SampleDate))

#assign regions
phyto2$Region<-ifelse(phyto2$StationCode %in% downstream, "Downstream",
                    ifelse(phyto2$StationCode %in% upstream, "Upstream", "Middle Sac River"))
phyto2$Region<-factor(phyto2$Region, levels=c("Upstream", "Downstream", "Middle Sac River"))

#calculate total biovolume by site and then mean biovolume for the region
total_phyto_mean<-phyto2%>%group_by(Region, StationCode)%>%summarize(total_biovolume=sum(BioV.per.mL))%>%
  group_by(Region)%>%summarize(Mean_biovolume=mean(total_biovolume), SD_biovolume=sd(total_biovolume))

#plot phytoplankton biovolume by region
phyto_plot1<-total_phyto_mean%>%filter(Region!="Middle Sac River")%>%ggplot(aes(x=Region, y=log(Mean_biovolume), fill=Region))+geom_bar(stat="identity")+geom_errorbar(aes(ymin=0, ymax=log(Mean_biovolume)+log(SD_biovolume)))+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab(bquote("Log Phytoplankton Biovolume (�"*m^3*'/mL)'))+
  annotate("text", x=0.5, y=40, label="a)", size=8)+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/SFHA Report/phyto.png", phyto_plot1, height=5, width=7, dpi=600)

#t-test for upstream/downstream differences
total_phyto_mean2<-phyto2%>%filter(Region!="Middle Sac River")%>%group_by(Region, StationCode)%>%summarize(total_biovolume=mean(BioV.per.mL))
phyto.t.test<-t.test(log(total_biovolume)~Region, total_phyto_mean2, alternative="two.sided", var.equal=FALSE)
phyto.t.test #upstream mean is significantly higher than downstream mean

#################### combined phyto and zoop plot #################################################################
phyto_zoop_plot<- ggarrange(phyto_plot1, zoop_plot2, ncol=2, nrow=1)
ggsave(filename="~/NDFA/2021/SFHA Report/phyto_zoop.png", phyto_zoop_plot, height=6, width=10, dpi=600)

#################### nutrients ####################################################################################
#ammonia, nitrate/nitrite, DOP

#read in separate excel files and combine for nutrient data
mydir = "~/NDFA/2021/SFHA Report/WQ_data"
wq <- list.files(path = mydir, pattern = "*.csv", full.names = T) %>% map_df(~read_csv(., col_types = cols(.default = "c"))) 

#data cleaning: remove rows with NA in collection date, remove rows with "duplicate or matrix spike" in notes
#subset to Dissolved ortho-phosphate, Dissolved Ammonia, Dissolved Nitrate + Nitrite
wq2<-wq%>%filter(Analyte%in%c("Dissolved Ammonia", "Dissolved Nitrate + Nitrite", "Dissolved ortho-Phosphate"))%>%
  filter(!is.na(CollectionDate))%>%filter(is.na(Notes))

#assign stations to upstream and downstream
downstream2<-c("RYI - Cache Slough","Liberty at S End",  "RVB - Rio Vista", "BL5 -Below Toe Drain")
upstream2<-c("Toe Drain at Rd. 22", "RMB - Rominger", "Ridge Cut Slough","Toe Drain at STTD", "Toe Drain YB LISBON", "Toe Drain@ I-80")

wq2$Region<-ifelse(wq2$ShortStationName %in% downstream2, "Downstream",
                    ifelse(wq2$ShortStationName %in% upstream2, "Upstream", "Middle Sac River"))
wq2$Region<-factor(wq2$Region, levels=c("Upstream", "Downstream", "Middle Sac River"))

#for non-detects, assign zero: any value with a < symbol
wq2$Result<-ifelse(wq2$Result %in% c("<0.05", "<0.01"), 0, wq2$Result)

#assign flow pulse period: before and after
wq2$PulsePeriod<-ifelse(wq2$CollectionDate %in% c("10/13/2020 09:06", "10/13/2020 10:15", "10/13/2020 11:07", "10/14/2020 11:48", "10/14/2020 12:46", "10/14/2020 14:26", "11/12/2020 12:00", "11/12/2020 13:05","11/12/2020 09:30","11/12/2020 08:45","11/12/2020 14:00"), "After","Before")
wq2$PulsePeriod<-factor(wq2$PulsePeriod, levels=c("Before", "After"))

#calculate mean for each analyte by region and pulse period
nutrient_means<-wq2%>%filter(PulsePeriod=="Before")%>%group_by(Analyte, Region, PulsePeriod)%>%summarize(mean=mean(as.numeric(Result)), sd=sd(as.numeric(Result)))

#change factor levels for Analytes for plotting
nutrient_means$Analyte[nutrient_means$Analyte=="Dissolved Ammonia"]<-"Ammonia"
nutrient_means$Analyte[nutrient_means$Analyte=="Dissolved ortho-Phosphate"]<-"Phosphate"
nutrient_means$Analyte[nutrient_means$Analyte=="Dissolved Nitrate + Nitrite"]<-"Nitrate/Nitrite"

#plot mean and sd by analyte, pulse period, region, filter Middle Sac River
nutrients_plot<-nutrient_means%>%filter(Region!="Middle Sac River")%>%ggplot(aes(x=Region, y=mean, fill=Region))+geom_bar(stat="identity")+geom_errorbar(aes(ymin=0, ymax=mean+sd))+facet_wrap(Analyte~.)+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab("Mean concentration (mg/L)")+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/SFHA Report/nutrients.png", nutrients_plot, height=6, width=7, dpi=600)

#t-test for differences in nutrient concentrations between upstream and downstream regions
#calculate mean by analyte and site for t-test
site_means<-wq2%>%filter(PulsePeriod=="Before")%>%filter(Region!="Middle Sac River")%>%group_by(Region, ShortStationName, Analyte)%>%summarize(mean=mean(as.numeric(Result)), sd=sd(as.numeric(Result)))

#can't run t-tests because of missing data values
ammonia<-filter(site_means, Analyte=="Dissolved Ammonia")
hist(log(ammonia$mean))
ammonia.t.test<-t.test(log(mean)~Region, ammonia, alternative="two.sided", var.equal=FALSE)
ammonia.t.test #upstream higher

##################### Discrete WQ ###############################################################################################
#DO, sp cond., pH, turbidity, secchi, temperature

physical_wq<-read_csv("YBFMP_WQ_Data.csv", na = c("", "N/A", "NA"))

#data cleaning: filter to NDFA, 2020 samples, change to long format for wq measurements
physical_wq2<-physical_wq%>%filter(Measuring.Program.Name%in%c("NDFA", "NDFS", "Shared"))%>%
  filter(`WDL SAM_COLLECTION_DATE`<="8/11/2020")%>%
  gather("secchi","water.temp","DO.probe","sp.cond","EC","pH", "turb.FNU", key="Analyte", value="Result")

#assign regions
physical_wq2$Region<-ifelse(physical_wq2$Station.Name %in% downstream, "Downstream",
                    ifelse(physical_wq2$Station.Name %in% upstream, "Upstream", "Middle Sac River"))
physical_wq2$Region<-factor(physical_wq2$Region, levels=c("Upstream", "Downstream", "Middle Sac River"))

#summarize values by region
phys_wq_means<-physical_wq2%>%group_by(Analyte, Region)%>%summarize(wq_mean=mean(Result, na.rm=TRUE), wq_sd=sd(Result, na.rm=TRUE))

#rename analytes
phys_wq_means$Analyte[phys_wq_means$Analyte=="DO.probe"]<-"Dissolved Oxygen (mg/L)"
phys_wq_means$Analyte[phys_wq_means$Analyte=="secchi"]<-"Secchi depth (m)"
phys_wq_means$Analyte[phys_wq_means$Analyte=="sp.cond"]<-"Spec. Cond. (�S/cm @ 25�C)"
phys_wq_means$Analyte[phys_wq_means$Analyte=="turb.FNU"]<-"Turbidity (FNU)"
phys_wq_means$Analyte[phys_wq_means$Analyte=="water.temp"]<-"Temperature (�C)"

#plot water quality by region- change to free y-scales
wq_plot<-phys_wq_means%>%filter(Region!="Middle Sac River")%>%filter(Analyte!="EC")%>%ggplot(aes(x=Region, y=wq_mean, fill=Region))+geom_bar(stat="identity")+geom_errorbar(aes(ymin=0, ymax=wq_mean+wq_sd))+facet_wrap(Analyte~., scales = "free_y")+
  scale_fill_viridis(discrete = TRUE, option="A")+
  xlab("Region")+ylab("Mean value")+
  theme_bw()+theme(legend.position = "none")+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.title.x = element_text(size=18), axis.title.y = element_text(size=18), axis.text.x = element_text(size=12), axis.text.y = element_text(size=12), strip.text=element_text(size=15))
ggsave(filename="~/NDFA/2021/SFHA Report/wq.png", wq_plot, height=6, width=10, dpi=600)

#run t-tests on physical water quality data
#group data by analyte and calculate site means
wq_site_means<-physical_wq2%>%filter(Region!="Middle Sac River")%>%group_by(Region, Station.Name, Analyte)%>%summarize(mean=mean(Result, na.rm=TRUE), sd=sd(Result, na.rm=TRUE))

#subset and test by analyte
DO<-filter(wq_site_means, Analyte=="DO.probe")
hist(log(DO$mean)) #no log-transformation
DO.t.test<-t.test(mean~Region, DO, alternative="two.sided", var.equal=FALSE)
DO.t.test #downstream higher

pH<-filter(wq_site_means, Analyte=="pH")
hist(log(pH$mean))
hist(pH$mean)#no log-transformation
pH.t.test<-t.test(mean~Region, pH, alternative="two.sided", var.equal=FALSE)
pH.t.test #not significantly different

secchi<-filter(wq_site_means, Analyte=="secchi")
hist(log(secchi$mean))
hist(secchi$mean)#no log-transformation
secchi.t.test<-t.test(mean~Region, secchi, alternative="two.sided", var.equal=FALSE)
secchi.t.test #downstream higher

sp.cond<-filter(wq_site_means, Analyte=="sp.cond")
hist(log(sp.cond$mean))
hist(sp.cond$mean)#no log-transformation
sp.cond.t.test<-t.test(mean~Region, sp.cond, alternative="two.sided", var.equal=FALSE)
sp.cond.t.test #upstream higher

turb.FNU<-filter(wq_site_means, Analyte=="turb.FNU")
hist(log(turb.FNU$mean))
hist(turb.FNU$mean)#no log-transformation
turb.FNU.t.test<-t.test(mean~Region, turb.FNU, alternative="two.sided", var.equal=FALSE)
turb.FNU.t.test #upstream higher

water.temp<-filter(wq_site_means, Analyte=="water.temp")
hist(log(water.temp$mean))
hist(water.temp$mean)#no log-transformation
water.temp.t.test<-t.test(mean~Region, water.temp, alternative="two.sided", var.equal=FALSE)
water.temp.t.test #upstream higher

##################### flow data from CDEC #######################################################################################
#look at LIS station metadata
#what sensors are available, numbers and period of record
cdec_datasets("lis")


#download LIS flow data- change end date to end of October when updating
LIS_E_flows<- CDECRetrieve::cdec_query("LIS", "20", "E", "2021-06-01","2021-10-12")
LIS_E_flows$location_id=as.factor(LIS_E_flows$location_id)
LIS_E_flows=LIS_E_flows[,c("datetime" ,"location_id","parameter_value")]


#just plot LIS flow data
#separate dates into year, month, day
#convert dates to months and seasons and calculate hourly mean flow
LIS_E_flows$datetime2<-LIS_E_flows$datetime
LIS_E_flows2<-LIS_E_flows%>%mutate(Month = month(datetime), #create a month and year variable
                                   Year = year(datetime), 
                                   Day = day(datetime), 
                                   Hour= hour(datetime))%>%
  separate(datetime2, into=c("date", "time"), sep=" ")%>%
  group_by(Month, Day)%>%
  mutate(daily_mean_flow=mean(parameter_value, na.rm=TRUE))%>%
  distinct(date, daily_mean_flow, .keep_all=TRUE)

#plot LIS flow for June-October
library(scales)
library(ggpubr)
plot<-LIS_E_flows2%>%ggplot(aes(x=datetime,y=daily_mean_flow))+geom_point(pch=20, size=1, color="black")+geom_smooth(size=1, color="blue", method="loess", span=0.1)+
  scale_x_datetime("",breaks=date_breaks("30 days"), labels=date_format("%m/%d")) +theme(axis.text.x=element_text(angle=90))+
  ylab("Flow (CFS)")+theme(legend.position = c(0.8, 0.9))+
  #you'll need to modify the min and max values to get the box after you add more dates to the data frame
  annotate("rect", xmin = LIS_E_flows2$datetime[103], xmax = LIS_E_flows2$datetime[106], ymin = -200, ymax = 30,fill="darkgrey",alpha = .2)+
  annotate("text", x=LIS_E_flows2$datetime[1], y=30, label="a", size=8)+
  theme_bw()+theme(plot.title = element_text(hjust = 0.5, size=20))+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.text.x=element_text(size=rel(1.5)), axis.text.y=element_text(size=rel(1.5)), axis.title.x = element_text(size=20), axis.title.y = element_text(size=15))

plot2<-LIS_E_flows2%>%filter(datetime>"2021-09-01"&datetime<"2021-10-01")%>%ggplot(aes(x=datetime,y=daily_mean_flow))+geom_point(pch=20,size=1, color="black")+geom_smooth(size=1, color="blue",method="loess", span=0.3)+
  scale_x_datetime("Date (2021)",breaks=date_breaks("5 days"), labels=date_format("%m/%d")) +theme(axis.text.x=element_text(angle=90))+
  ylab("Flow (CFS)")+theme(legend.position = c(0.8, 0.9))+
  #you'll need to modify the min and max values to get the box after you add more dates to the data frame
  annotate("rect", xmin = LIS_E_flows2$datetime[103], xmax = LIS_E_flows2$datetime[106], ymin = -100, ymax = 50,fill="darkgrey",alpha = .2)+
  annotate("text", x=LIS_E_flows2$datetime[94], y=47, label="b", size=8)+
  theme_bw()+theme(plot.title = element_text(hjust = 0.5, size=20))+theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+theme(axis.text.x=element_text(size=rel(1.5)), axis.text.y=element_text(size=rel(1.5)), axis.title.x = element_text(size=20), axis.title.y = element_text(size=15))

#combine into one plot

flow_plot<- ggarrange(plot, plot2, ncol=1, nrow=2)
ggsave(filename="~/NDFA/2021/SFHA Report/flow.png", flow_plot, height=10, width=8, dpi=600)

################### save script workspace image #######################################################################
save.image("SFHA_report.RData")
